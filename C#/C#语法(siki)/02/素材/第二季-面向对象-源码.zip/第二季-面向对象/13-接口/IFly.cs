﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _13_接口
{
    interface IFly
    {
        void Fly();
        void FlyAttack();
    }
}
