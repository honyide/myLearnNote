﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Json操作
{
    class Skill
    {
        public int id { get; set; }
        public string name { get; set; }
        public int damage { get; set; }
    }
}
