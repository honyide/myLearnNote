﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _13_反射
{
    internal class MyClass
    {
        private int a;
        private int b;
        public int c;
        public string d;

        public string Name { get; set; }
        public string Name2 { get; set; }
        public void test1()
        {

        }
        public void test2()
        {

        }
    }
}
