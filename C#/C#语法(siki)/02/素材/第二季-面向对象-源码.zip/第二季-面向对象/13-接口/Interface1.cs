﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _13_接口
{
    interface Interface1
    {
        void Method1();
    }
}
