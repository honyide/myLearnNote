﻿// See https://aka.ms/new-console-template for more information

using System.Text;

//StringBuilder sb = new StringBuilder("www.sikiedu.com");

//sb.Append("123111");
//sb.Append("wwwww");

//sb.Insert(3, " ");

//sb.Remove(4, 2);

//sb.Replace("i", "Love");

//Console.WriteLine(sb);

// http://  www.sikiedu.com
//string s = "http://" + "www.sikiedu.com";
//s += " 我爱中国";

//StringBuilder sb = new StringBuilder();
//sb.Append("http://");
//sb.Append("www.sikiedu.com");

//List
//StringBuilder sb = new StringBuilder(5);
//sb.Append("http");
//sb.Append("www.sikiedu.com");
//Console.WriteLine(sb.Capacity);

StringBuilder sb = new StringBuilder("www.sikiedu.com",100);