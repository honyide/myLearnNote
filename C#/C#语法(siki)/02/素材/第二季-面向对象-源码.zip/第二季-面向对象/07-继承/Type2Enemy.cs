﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07_继承
{
    class Type2Enemy:Enemy
    {
    }
}
