﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08_虚方法
{
    class Type1Enemy:Enemy
    {
    }
}
