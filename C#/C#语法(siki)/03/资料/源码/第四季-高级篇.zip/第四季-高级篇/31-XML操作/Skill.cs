﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _31_XML操作
{
    class Skill
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Lang { get; set; }
        public int Damage { get; set; }
    }
}
