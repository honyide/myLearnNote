﻿using System;

namespace _12_静态_static
{
    class Program
    {
        static void Main(string[] args)
        {
            //Test t1 = new Test();
            //t1.hp = 100;
            //Test t2 = new Test();
            //t2.hp = 200;

            //Test.count = 1;

            //Test.count = 2;

            //Console.Write(Test.count);

            Test.Move();
        }
    }
}
