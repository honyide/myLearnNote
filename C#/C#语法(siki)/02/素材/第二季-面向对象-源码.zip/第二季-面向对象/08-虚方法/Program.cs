﻿using System;

namespace _08_虚方法
{
    class Program
    {
        static void Main(string[] args)
        {
            //Boss b = new Boss();
            //b.Move();

            //Enemy enemy;
            ////enemy = new Boss();
            ////enemy = new Type1Enemy();

            //enemy = new Boss();

            //enemy = new Type1Enemy();

            //Boss b1 = new Boss();
            //b1.Move();

            //Enemy b2 = new Boss();
            //b2.Move();
            //Enemy enemy = new Enemy();
            //enemy.Move();

            //Boss b = new Boss();
            //b.AI();

            Enemy b = new Boss();
            b.AI();

        }
    }
}
