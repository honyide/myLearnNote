﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _16_结构体和类的不同
{
    class Student
    {
        public int age;
        public string name;

        public Student(int age, string name)
        {
            this.age = age;
            this.name = name;
        }

        //重构 - 重新设计 - 架构师

    }
}
