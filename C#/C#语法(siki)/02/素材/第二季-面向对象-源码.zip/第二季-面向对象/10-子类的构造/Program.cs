﻿using System;
using _09_抽象类;

namespace _10_子类的构造
{
    class Program
    {
        static void Main(string[] args)
        {
            DrivedClass dc = new DrivedClass(100,80,10);
            Boss b = new Boss();

            // 1、添加别的项目的引用  2、引入命名空间  3、把类设置为public
            

        }
    }
}
