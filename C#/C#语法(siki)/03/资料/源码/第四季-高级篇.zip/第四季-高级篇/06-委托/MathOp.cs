﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06_委托
{
    internal class MathOp
    {
        public static double MultiplayByTwo(double value)
        {
            return value * 2;
        }
        public static double Square(double value)
        {
            return value * value;
        }
    }
}
