﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09_抽象类
{
    class Base
    {
        public virtual void Move()
        {

        }
    }
}
