﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07_继承
{
    class BaseClass
    {
        public int data1;
        public string data2;



        public void Function1()
        {
            Console.WriteLine("BaseClass:Function1");
        }
        public void Function2()
        {
            Console.WriteLine("BaseClass:Function2");
        }

    }
}
