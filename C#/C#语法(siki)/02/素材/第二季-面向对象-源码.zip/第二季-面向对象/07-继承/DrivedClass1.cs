﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07_继承
{
    class DrivedClass1:BaseClass
    {
        public int data3;

        public void FunctionDrivedClass1()
        {
            Console.WriteLine("FunctionDrivedClass1");
        }

    }
}
