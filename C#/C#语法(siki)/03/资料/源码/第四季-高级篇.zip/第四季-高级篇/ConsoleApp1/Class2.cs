﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Mynamespace2
{
    namespace ChildNamespace
    {
        internal class Class2
        {
        }
    }
}
