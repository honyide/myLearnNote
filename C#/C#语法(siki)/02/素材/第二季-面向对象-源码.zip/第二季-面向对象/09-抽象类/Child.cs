﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09_抽象类
{
    class Child:Base
    {
        public sealed override void Move()
        {
        }
    }
}
