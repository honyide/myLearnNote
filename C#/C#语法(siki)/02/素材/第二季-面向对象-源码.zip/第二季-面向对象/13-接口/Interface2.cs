﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _13_接口
{
    interface Interface2:Interface1
    {
        void Method2();
    }
}
