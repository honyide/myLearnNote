﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _13_接口
{
    class ClassInterface2 : Bird,Interface2,Interface1
    {
        public void Method1()
        {
        }

        public void Method2()
        {
        }
    }
}
